# Bexo BD Security Migration Guide

## Overview

This release fixes **4 critical security vulnerabilities**:

1. **Admin backdoor** - hardcoded `bexobd@gmail.com` that accepted any password if cloud lookup was offline
2. **Client-side password fallback** - login could succeed without proving credentials to the server, just by matching stale localStorage data
3. **App-level password storage** - plaintext-equivalent (base64) passwords shipped to browsers and stored in database table
4. **Cross-device profile sync failure** - devices stuck showing stale data because they couldn't establish real Supabase Auth sessions

Additionally:
- Registration now creates real Supabase Auth accounts instead of failing silently
- Profile changes on one device now instantly sync to all others via Realtime subscriptions

## Deployment Sequence

### Step 1: Deploy the Fixed App Code

Push the fixed `/public/app.js`, `/index.html`, and other files from this package to Vercel/your server.

**Users can continue logging in during this step** — the new code is backward-compatible.

### Step 2: Backfill Missing Auth Accounts (One-time, Local)

**BEFORE** you drop any password columns, you must create real Supabase Auth accounts for any legacy users who don't have one yet.

#### Prerequisites
- Node.js 18+
- Your Supabase **Service Role Key** (read-only for this operation, but keep it secret)
  - Find it: Supabase Dashboard → Project Settings → API
  - **Never commit this to git or expose it to browsers**

#### Run the Migration

```bash
cd migrations
npm install @supabase/supabase-js

# Set environment variables (use .env or export)
export SUPABASE_URL=https://your-project.supabase.co
export SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# Preview what will happen (no changes made)
node backfill-legacy-auth-accounts.mjs --dry-run

# If the dry run looks correct, run for real
node backfill-legacy-auth-accounts.mjs
```

**What it does:**
- Finds every `bexo_users` row with an `enc_password` that doesn't have a corresponding Supabase Auth account
- Decodes that password (server-side only)
- Creates a real Supabase Auth account with the same email & password
- Links the `bexo_users` row to the new Auth account by updating its `id` column
- These users can now log in with their existing credentials

**Spot-check:** Log in as one of your test users on both a phone and laptop to verify profiles sync correctly.

### Step 3: Drop the Password Columns (One-time, in Supabase)

Once all users have been migrated and you've verified a few logins work, run the SQL migration:

1. Go to Supabase Dashboard → SQL Editor
2. Paste the contents of `migrations/2026-08-drop-password-columns.sql`
3. Review it — it only drops two columns that are no longer used
4. Click "Run"

**After this step:**
- The database can no longer leak password data (it doesn't have any)
- Existing backups will eventually be purged per your Supabase retention policy

---

## Verification Checklist

After deployment:

- [ ] **Login flow** — sign in with an existing account on both phone & laptop
- [ ] **Profile sync** — edit your name on laptop, verify it appears on phone within 1-2 seconds
- [ ] **New registration** — create a brand-new account, verify an email confirmation link arrives
- [ ] **Admin access** — if you have admin users, verify they can still access the admin panel
- [ ] **Offline login** — disable network, try to sign in with correct credentials (should fail cleanly, not accept wrong password)
- [ ] **Cross-device logout** — sign out on one device, verify the session ends on all others

---

## Troubleshooting

### "Migration script fails with 'no such column: password'"

The `enc_password` column was already dropped. That's fine — the backfill script skips rows without stored passwords.

### "Users can't log in after deploying the new app"

Most likely: a user with no real Supabase Auth account tried to log in. This means the backfill didn't run or didn't complete successfully. **Roll back the app code**, run the backfill, then re-deploy.

### "One user's profile synced instantly, but another's didn't"

The first user has realtime Postgres changes enabled in their Supabase project (default). The second user might be offline or in an old browser tab. Refreshing the page will sync immediately via `onAuthStateChange` listener.

### "Old password field data is still visible in exports"

If you exported data before dropping the columns, those exports are stale. Re-export from the updated tables.

---

## What Changed in the App Code

| Vulnerability | Fix |
|---|---|
| Admin backdoor | Removed entire `if (cleanIdentifier === 'bexobd@gmail.com')` block that fabricated sessions. Admin role now only comes from real Supabase Auth. |
| Local password fallback | Removed `localPassMatch` variable and client-side password comparison. Login only succeeds via `auth.signInWithPassword()`. |
| App-level passwords | Stopped writing `password` / `enc_password` to DB. Stopped reading/decoding them from queries. |
| Cross-device drift | Added realtime channel subscription (`subscribeToOwnProfileRealtime`) to pull fresh data instantly. Added `onAuthStateChange` listener so login/token-refresh immediately triggers sync. |
| Silent registration failure | Changed `auth.updateUser()` → `auth.signUp()` so new accounts are created in Supabase Auth. Added email confirmation flow. |

---

## Support

If anything breaks:

1. Check the browser console (F12 → Console tab) for error messages
2. Check your Supabase project logs (Supabase Dashboard → Logs → Edge Functions / Auth)
3. Review this guide's Troubleshooting section

For critical issues, consider rolling back to a pre-migration backup while you investigate.

---

## Security Notes

- **Password hashing is now Supabase Auth's job.** The app never sees plaintext passwords except the moment the user types them into the login/register form.
- **Realtime subscriptions use Postgres' native `postgres_changes` feature**, which respects your Row-Level Security policies. One user cannot subscribe to another user's profile changes.
- **Email confirmation:** If you've enabled "Confirm email before sign in" in Supabase Auth settings, new registrations will require the user to click a link in their email. Adjust this setting in Supabase Dashboard → Authentication → Providers → Email.

---

**Migration completed:** Your app is now production-ready with proper authentication and secure credential handling.

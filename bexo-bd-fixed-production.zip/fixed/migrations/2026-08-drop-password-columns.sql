-- ============================================================================
-- Bexo BD - Security migration: remove app-level password storage
-- Run this once in the Supabase SQL editor for your project.
-- ============================================================================
--
-- WHY: bexo_users had a `password` / `enc_password` column that the app used
-- to store a copy of the user's password (enc_password was base64 - NOT real
-- encryption, trivially reversible by anyone who could read the row). The
-- real, properly-hashed credential already lives in Supabase Auth's own
-- storage (auth.users) and is all the app should ever rely on.
--
-- The client code has been updated to stop writing/reading these columns.
-- This migration removes the historical data so it can't leak from anywhere
-- (admin panel, exports, direct table access, a future bug, etc).
--
-- BEFORE RUNNING: make sure every real user has already been able to log in
-- with a real Supabase Auth account at least once since deploying the fixed
-- app (see MIGRATION-NOTES.md in the project root for the details on why).

ALTER TABLE public.bexo_users DROP COLUMN IF EXISTS password;
ALTER TABLE public.bexo_users DROP COLUMN IF EXISTS enc_password;

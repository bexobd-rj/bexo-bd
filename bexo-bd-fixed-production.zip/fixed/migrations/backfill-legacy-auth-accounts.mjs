/**
 * ONE-TIME MIGRATION - run this locally, once, BEFORE running
 * 2026-08-drop-password-columns.sql.
 *
 * WHY THIS EXISTS
 * ----------------
 * The registration code in this app previously called `supabase.auth.updateUser()`
 * instead of `supabase.auth.signUp()`. `updateUser()` only edits an ALREADY
 * signed-in session - it does not create a new account. Since the app never
 * called `signInAnonymously()` either, this means most/all users who registered
 * before this fix was deployed have a row in `bexo_users` but NO real Supabase
 * Auth account. Their login has been "working" only because the app used to
 * compare the typed password against a plaintext-ish `enc_password` column
 * stored in that table - which is the exact insecure pattern this whole fix
 * removes.
 *
 * This script bridges the gap safely and ONCE:
 *   1. Reads every bexo_users row that still has an enc_password and does not
 *      already look like a real Supabase Auth user.
 *   2. Decodes that password (server-side only, using your SERVICE ROLE key -
 *      never expose this key to a browser).
 *   3. Creates a real Supabase Auth account for that user with the same email
 *      and password, so they can keep logging in with what they already know.
 *   4. Updates the bexo_users row's `id` to the new Auth user id (required for
 *      the RLS policies in supabase_schema.sql, which check `auth.uid() = id`).
 *
 * AFTER this script finishes successfully and you've spot-checked a few
 * accounts, you can safely run migrations/2026-08-drop-password-columns.sql.
 *
 * HOW TO RUN
 * ----------
 *   1. npm install @supabase/supabase-js
 *   2. Set these env vars (get the service role key from
 *      Supabase Dashboard -> Project Settings -> API - keep it secret, do not
 *      commit it, do not put it in Vercel's client-exposed env vars):
 *        SUPABASE_URL=https://xxxx.supabase.co
 *        SUPABASE_SERVICE_ROLE_KEY=xxxx
 *   3. node migrations/backfill-legacy-auth-accounts.mjs --dry-run   (preview)
 *   4. node migrations/backfill-legacy-auth-accounts.mjs             (apply)
 */

import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const DRY_RUN = process.argv.includes('--dry-run');

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars.');
  process.exit(1);
}

const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function decodePassword(encPassword) {
  try {
    return decodeURIComponent(escape(Buffer.from(encPassword, 'base64').toString('binary')));
  } catch {
    return null;
  }
}

async function main() {
  console.log(DRY_RUN ? '--- DRY RUN (no changes will be made) ---' : '--- LIVE RUN ---');

  const { data: rows, error } = await admin
    .from('bexo_users')
    .select('id, email, phone, profileId, enc_password')
    .not('enc_password', 'is', null)
    .not('email', 'is', null);

  if (error) {
    console.error('Failed to read bexo_users:', error.message);
    process.exit(1);
  }

  console.log(`Found ${rows.length} row(s) with a stored password to check.`);

  let created = 0, skipped = 0, failed = 0;

  for (const row of rows) {
    const email = (row.email || '').toLowerCase().trim();
    if (!email) { skipped++; continue; }

    // Skip if a real auth account with this email already exists.
    const { data: existing } = await admin.auth.admin.listUsers({ page: 1, perPage: 1, email });
    if (existing && existing.users && existing.users.some(u => (u.email || '').toLowerCase() === email)) {
      console.log(`SKIP (already has auth account): ${email}`);
      skipped++;
      continue;
    }

    const password = decodePassword(row.enc_password);
    if (!password || password.length < 6) {
      console.warn(`SKIP (could not decode a usable password): ${email}`);
      skipped++;
      continue;
    }

    console.log(`${DRY_RUN ? '[dry-run] would create' : 'creating'} auth account for ${email} (profileId ${row.profileId})`);
    if (DRY_RUN) { created++; continue; }

    const { data: newUser, error: createErr } = await admin.auth.admin.createUser({
      email,
      password,
      phone: row.phone || undefined,
      email_confirm: true,
      user_metadata: { profileId: row.profileId, migratedFromLegacyAccount: true },
    });

    if (createErr) {
      console.error(`FAILED for ${email}:`, createErr.message);
      failed++;
      continue;
    }

    const { error: updateErr } = await admin
      .from('bexo_users')
      .update({ id: newUser.user.id })
      .eq('profileId', row.profileId);

    if (updateErr) {
      console.error(`Created auth user for ${email} but FAILED to relink bexo_users row:`, updateErr.message);
      failed++;
      continue;
    }

    created++;
  }

  console.log(`\nDone. created=${created} skipped=${skipped} failed=${failed}`);
  if (DRY_RUN) console.log('This was a dry run - nothing was written. Re-run without --dry-run to apply.');
}

main();
